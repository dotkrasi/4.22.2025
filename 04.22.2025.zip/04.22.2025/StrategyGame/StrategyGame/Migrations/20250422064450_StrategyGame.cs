﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StrategyGame.Migrations
{
    /// <inheritdoc />
    public partial class StrategyGame : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Factions",
                columns: table => new
                {
                    factions_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Factions__09F849E3F9FE8722", x => x.factions_id);
                });

            migrationBuilder.CreateTable(
                name: "Maps",
                columns: table => new
                {
                    maps_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    SizeX = table.Column<int>(type: "int", nullable: true),
                    SizeY = table.Column<int>(type: "int", nullable: true),
                    description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Maps__27C645093A598820", x => x.maps_id);
                });

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    player_id = table.Column<int>(type: "int", nullable: false),
                    username = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedAt = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Players__44DA120CC6C8806B", x => x.player_id);
                });

            migrationBuilder.CreateTable(
                name: "Resources",
                columns: table => new
                {
                    resources_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Resource__F6DB0162F980C05F", x => x.resources_id);
                });

            migrationBuilder.CreateTable(
                name: "Technologies",
                columns: table => new
                {
                    technologies_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    ResearchTime = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Technolo__181FA18129E5FFEA", x => x.technologies_id);
                });

            migrationBuilder.CreateTable(
                name: "Buildings",
                columns: table => new
                {
                    buildings_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    BuildTime = table.Column<int>(type: "int", nullable: true),
                    faction_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Building__BF10570748798B06", x => x.buildings_id);
                    table.ForeignKey(
                        name: "FK__Buildings__facti__1BC821DD",
                        column: x => x.faction_id,
                        principalTable: "Factions",
                        principalColumn: "factions_id");
                });

            migrationBuilder.CreateTable(
                name: "Units",
                columns: table => new
                {
                    units_id = table.Column<int>(type: "int", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    attack_power = table.Column<int>(type: "int", nullable: true),
                    defense_power = table.Column<int>(type: "int", nullable: true),
                    training_time = table.Column<int>(type: "int", nullable: true),
                    faction_id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Units__E2E4534555941260", x => x.units_id);
                    table.ForeignKey(
                        name: "FK__Units__faction_i__22751F6C",
                        column: x => x.faction_id,
                        principalTable: "Factions",
                        principalColumn: "factions_id");
                });

            migrationBuilder.CreateTable(
                name: "Battles",
                columns: table => new
                {
                    battles_id = table.Column<int>(type: "int", nullable: false),
                    attacker_id = table.Column<int>(type: "int", nullable: true),
                    defender_id = table.Column<int>(type: "int", nullable: true),
                    StartedAt = table.Column<DateOnly>(type: "date", nullable: true),
                    EndedAt = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Battles__AF3E84008CBBCEAE", x => x.battles_id);
                    table.ForeignKey(
                        name: "FK__Battles__attacke__2EDAF651",
                        column: x => x.attacker_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                    table.ForeignKey(
                        name: "FK__Battles__defende__2FCF1A8A",
                        column: x => x.defender_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerFactions",
                columns: table => new
                {
                    player_factions_id = table.Column<int>(type: "int", nullable: false),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    faction_id = table.Column<int>(type: "int", nullable: true),
                    StartDate = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerFa__07827B84473AD6A5", x => x.player_factions_id);
                    table.ForeignKey(
                        name: "FK__PlayerFac__facti__18EBB532",
                        column: x => x.faction_id,
                        principalTable: "Factions",
                        principalColumn: "factions_id");
                    table.ForeignKey(
                        name: "FK__PlayerFac__playe__17F790F9",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerLocations",
                columns: table => new
                {
                    playerlocations_id = table.Column<int>(type: "int", nullable: false),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    maps_id = table.Column<int>(type: "int", nullable: true),
                    X = table.Column<int>(type: "int", nullable: true),
                    Y = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerLo__AB9987B3C743BBA7", x => x.playerlocations_id);
                    table.ForeignKey(
                        name: "FK__PlayerLoc__maps___3A4CA8FD",
                        column: x => x.maps_id,
                        principalTable: "Maps",
                        principalColumn: "maps_id");
                    table.ForeignKey(
                        name: "FK__PlayerLoc__playe__395884C4",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerResources",
                columns: table => new
                {
                    player_resources_id = table.Column<int>(type: "int", nullable: false),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    resources_id = table.Column<int>(type: "int", nullable: true),
                    Amount = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerRe__CAE84B8450B5E95B", x => x.player_resources_id);
                    table.ForeignKey(
                        name: "FK__PlayerRes__playe__2B0A656D",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                    table.ForeignKey(
                        name: "FK__PlayerRes__resou__2BFE89A6",
                        column: x => x.resources_id,
                        principalTable: "Resources",
                        principalColumn: "resources_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerTechnologies",
                columns: table => new
                {
                    player_technologies_id = table.Column<int>(type: "int", nullable: false),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    technologies_id = table.Column<int>(type: "int", nullable: true),
                    IsResearched = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    ResearchedAt = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerTe__075B74902F843B85", x => x.player_technologies_id);
                    table.ForeignKey(
                        name: "FK__PlayerTec__playe__3F115E1A",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                    table.ForeignKey(
                        name: "FK__PlayerTec__techn__40058253",
                        column: x => x.technologies_id,
                        principalTable: "Technologies",
                        principalColumn: "technologies_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerBuildings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    buildings_id = table.Column<int>(type: "int", nullable: true),
                    level = table.Column<int>(type: "int", nullable: true),
                    BuiltAt = table.Column<DateOnly>(type: "date", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerBu__3214EC07457E242A", x => x.Id);
                    table.ForeignKey(
                        name: "FK__PlayerBui__build__1F98B2C1",
                        column: x => x.buildings_id,
                        principalTable: "Buildings",
                        principalColumn: "buildings_id");
                    table.ForeignKey(
                        name: "FK__PlayerBui__playe__1EA48E88",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                });

            migrationBuilder.CreateTable(
                name: "BattleUnits",
                columns: table => new
                {
                    battle_units_id = table.Column<int>(type: "int", nullable: false),
                    BattleId = table.Column<int>(type: "int", nullable: true),
                    UnitId = table.Column<int>(type: "int", nullable: true),
                    PlayerId = table.Column<int>(type: "int", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__BattleUn__C33582F925B0B1B2", x => x.battle_units_id);
                    table.ForeignKey(
                        name: "FK__BattleUni__Battl__32AB8735",
                        column: x => x.BattleId,
                        principalTable: "Buildings",
                        principalColumn: "buildings_id");
                    table.ForeignKey(
                        name: "FK__BattleUni__Playe__3493CFA7",
                        column: x => x.PlayerId,
                        principalTable: "Players",
                        principalColumn: "player_id");
                    table.ForeignKey(
                        name: "FK__BattleUni__UnitI__339FAB6E",
                        column: x => x.UnitId,
                        principalTable: "Units",
                        principalColumn: "units_id");
                });

            migrationBuilder.CreateTable(
                name: "PlayerUnits",
                columns: table => new
                {
                    player_units_id = table.Column<int>(type: "int", nullable: false),
                    player_id = table.Column<int>(type: "int", nullable: true),
                    units_id = table.Column<int>(type: "int", nullable: true),
                    Quantity = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__PlayerUn__B87478E7E6936005", x => x.player_units_id);
                    table.ForeignKey(
                        name: "FK__PlayerUni__playe__25518C17",
                        column: x => x.player_id,
                        principalTable: "Players",
                        principalColumn: "player_id");
                    table.ForeignKey(
                        name: "FK__PlayerUni__units__2645B050",
                        column: x => x.units_id,
                        principalTable: "Units",
                        principalColumn: "units_id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Battles_attacker_id",
                table: "Battles",
                column: "attacker_id");

            migrationBuilder.CreateIndex(
                name: "IX_Battles_defender_id",
                table: "Battles",
                column: "defender_id");

            migrationBuilder.CreateIndex(
                name: "IX_BattleUnits_BattleId",
                table: "BattleUnits",
                column: "BattleId");

            migrationBuilder.CreateIndex(
                name: "IX_BattleUnits_PlayerId",
                table: "BattleUnits",
                column: "PlayerId");

            migrationBuilder.CreateIndex(
                name: "IX_BattleUnits_UnitId",
                table: "BattleUnits",
                column: "UnitId");

            migrationBuilder.CreateIndex(
                name: "IX_Buildings_faction_id",
                table: "Buildings",
                column: "faction_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerBuildings_buildings_id",
                table: "PlayerBuildings",
                column: "buildings_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerBuildings_player_id",
                table: "PlayerBuildings",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerFactions_faction_id",
                table: "PlayerFactions",
                column: "faction_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerFactions_player_id",
                table: "PlayerFactions",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerLocations_maps_id",
                table: "PlayerLocations",
                column: "maps_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerLocations_player_id",
                table: "PlayerLocations",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerResources_player_id",
                table: "PlayerResources",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerResources_resources_id",
                table: "PlayerResources",
                column: "resources_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerTechnologies_player_id",
                table: "PlayerTechnologies",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerTechnologies_technologies_id",
                table: "PlayerTechnologies",
                column: "technologies_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerUnits_player_id",
                table: "PlayerUnits",
                column: "player_id");

            migrationBuilder.CreateIndex(
                name: "IX_PlayerUnits_units_id",
                table: "PlayerUnits",
                column: "units_id");

            migrationBuilder.CreateIndex(
                name: "IX_Units_faction_id",
                table: "Units",
                column: "faction_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Battles");

            migrationBuilder.DropTable(
                name: "BattleUnits");

            migrationBuilder.DropTable(
                name: "PlayerBuildings");

            migrationBuilder.DropTable(
                name: "PlayerFactions");

            migrationBuilder.DropTable(
                name: "PlayerLocations");

            migrationBuilder.DropTable(
                name: "PlayerResources");

            migrationBuilder.DropTable(
                name: "PlayerTechnologies");

            migrationBuilder.DropTable(
                name: "PlayerUnits");

            migrationBuilder.DropTable(
                name: "Buildings");

            migrationBuilder.DropTable(
                name: "Maps");

            migrationBuilder.DropTable(
                name: "Resources");

            migrationBuilder.DropTable(
                name: "Technologies");

            migrationBuilder.DropTable(
                name: "Players");

            migrationBuilder.DropTable(
                name: "Units");

            migrationBuilder.DropTable(
                name: "Factions");
        }
    }
}
