﻿using Microsoft.EntityFrameworkCore;
using StrategyGame.Data.Models;

namespace StrategyGame.Data;

public partial class StrategyGameContext : DbContext
{
    public StrategyGameContext()
    {
    }

    public StrategyGameContext(DbContextOptions<StrategyGameContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Battle> Battles { get; set; }

    public virtual DbSet<BattleUnit> BattleUnits { get; set; }

    public virtual DbSet<Building> Buildings { get; set; }

    public virtual DbSet<Faction> Factions { get; set; }

    public virtual DbSet<Map> Maps { get; set; }

    public virtual DbSet<Player> Players { get; set; }

    public virtual DbSet<PlayerBuilding> PlayerBuildings { get; set; }

    public virtual DbSet<PlayerFaction> PlayerFactions { get; set; }

    public virtual DbSet<PlayerLocation> PlayerLocations { get; set; }

    public virtual DbSet<PlayerResource> PlayerResources { get; set; }

    public virtual DbSet<PlayerTechnology> PlayerTechnologies { get; set; }

    public virtual DbSet<PlayerUnit> PlayerUnits { get; set; }

    public virtual DbSet<Resource> Resources { get; set; }

    public virtual DbSet<Technology> Technologies { get; set; }

    public virtual DbSet<Unit> Units { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=StrategyGame;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Battle>(entity =>
        {
            entity.HasKey(e => e.BattlesId).HasName("PK__Battles__AF3E84008CBBCEAE");

            entity.Property(e => e.BattlesId)
                .ValueGeneratedNever()
                .HasColumnName("battles_id");
            entity.Property(e => e.AttackerId).HasColumnName("attacker_id");
            entity.Property(e => e.DefenderId).HasColumnName("defender_id");

            entity.HasOne(d => d.Attacker).WithMany(p => p.BattleAttackers)
                .HasForeignKey(d => d.AttackerId)
                .HasConstraintName("FK__Battles__attacke__2EDAF651");

            entity.HasOne(d => d.Defender).WithMany(p => p.BattleDefenders)
                .HasForeignKey(d => d.DefenderId)
                .HasConstraintName("FK__Battles__defende__2FCF1A8A");
        });

        modelBuilder.Entity<BattleUnit>(entity =>
        {
            entity.HasKey(e => e.BattleUnitsId).HasName("PK__BattleUn__C33582F925B0B1B2");

            entity.Property(e => e.BattleUnitsId)
                .ValueGeneratedNever()
                .HasColumnName("battle_units_id");

            entity.HasOne(d => d.Battle).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.BattleId)
                .HasConstraintName("FK__BattleUni__Battl__32AB8735");

            entity.HasOne(d => d.Player).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__BattleUni__Playe__3493CFA7");

            entity.HasOne(d => d.Unit).WithMany(p => p.BattleUnits)
                .HasForeignKey(d => d.UnitId)
                .HasConstraintName("FK__BattleUni__UnitI__339FAB6E");
        });

        modelBuilder.Entity<Building>(entity =>
        {
            entity.HasKey(e => e.BuildingsId).HasName("PK__Building__BF10570748798B06");

            entity.Property(e => e.BuildingsId)
                .ValueGeneratedNever()
                .HasColumnName("buildings_id");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .HasColumnName("description");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");

            entity.HasOne(d => d.Faction).WithMany(p => p.Buildings)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__Buildings__facti__1BC821DD");
        });

        modelBuilder.Entity<Faction>(entity =>
        {
            entity.HasKey(e => e.FactionsId).HasName("PK__Factions__09F849E3F9FE8722");

            entity.Property(e => e.FactionsId)
                .ValueGeneratedNever()
                .HasColumnName("factions_id");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Map>(entity =>
        {
            entity.HasKey(e => e.MapsId).HasName("PK__Maps__27C645093A598820");

            entity.Property(e => e.MapsId)
                .ValueGeneratedNever()
                .HasColumnName("maps_id");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Player>(entity =>
        {
            entity.HasKey(e => e.PlayerId).HasName("PK__Players__44DA120CC6C8806B");

            entity.Property(e => e.PlayerId)
                .ValueGeneratedNever()
                .HasColumnName("player_id");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.Username)
                .HasMaxLength(100)
                .HasColumnName("username");
        });

        modelBuilder.Entity<PlayerBuilding>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__PlayerBu__3214EC07457E242A");

            entity.Property(e => e.BuildingsId).HasColumnName("buildings_id");
            entity.Property(e => e.Level).HasColumnName("level");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Buildings).WithMany(p => p.PlayerBuildings)
                .HasForeignKey(d => d.BuildingsId)
                .HasConstraintName("FK__PlayerBui__build__1F98B2C1");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerBuildings)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerBui__playe__1EA48E88");
        });

        modelBuilder.Entity<PlayerFaction>(entity =>
        {
            entity.HasKey(e => e.PlayerFactionsId).HasName("PK__PlayerFa__07827B84473AD6A5");

            entity.Property(e => e.PlayerFactionsId)
                .ValueGeneratedNever()
                .HasColumnName("player_factions_id");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Faction).WithMany(p => p.PlayerFactions)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__PlayerFac__facti__18EBB532");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerFactions)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerFac__playe__17F790F9");
        });

        modelBuilder.Entity<PlayerLocation>(entity =>
        {
            entity.HasKey(e => e.PlayerlocationsId).HasName("PK__PlayerLo__AB9987B3C743BBA7");

            entity.Property(e => e.PlayerlocationsId)
                .ValueGeneratedNever()
                .HasColumnName("playerlocations_id");
            entity.Property(e => e.MapsId).HasColumnName("maps_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Maps).WithMany(p => p.PlayerLocations)
                .HasForeignKey(d => d.MapsId)
                .HasConstraintName("FK__PlayerLoc__maps___3A4CA8FD");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerLocations)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerLoc__playe__395884C4");
        });

        modelBuilder.Entity<PlayerResource>(entity =>
        {
            entity.HasKey(e => e.PlayerResourcesId).HasName("PK__PlayerRe__CAE84B8450B5E95B");

            entity.Property(e => e.PlayerResourcesId)
                .ValueGeneratedNever()
                .HasColumnName("player_resources_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.ResourcesId).HasColumnName("resources_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerResources)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerRes__playe__2B0A656D");

            entity.HasOne(d => d.Resources).WithMany(p => p.PlayerResources)
                .HasForeignKey(d => d.ResourcesId)
                .HasConstraintName("FK__PlayerRes__resou__2BFE89A6");
        });

        modelBuilder.Entity<PlayerTechnology>(entity =>
        {
            entity.HasKey(e => e.PlayerTechnologiesId).HasName("PK__PlayerTe__075B74902F843B85");

            entity.Property(e => e.PlayerTechnologiesId)
                .ValueGeneratedNever()
                .HasColumnName("player_technologies_id");
            entity.Property(e => e.IsResearched).HasMaxLength(1);
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.TechnologiesId).HasColumnName("technologies_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerTechnologies)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerTec__playe__3F115E1A");

            entity.HasOne(d => d.Technologies).WithMany(p => p.PlayerTechnologies)
                .HasForeignKey(d => d.TechnologiesId)
                .HasConstraintName("FK__PlayerTec__techn__40058253");
        });

        modelBuilder.Entity<PlayerUnit>(entity =>
        {
            entity.HasKey(e => e.PlayerUnitsId).HasName("PK__PlayerUn__B87478E7E6936005");

            entity.Property(e => e.PlayerUnitsId)
                .ValueGeneratedNever()
                .HasColumnName("player_units_id");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.UnitsId).HasColumnName("units_id");

            entity.HasOne(d => d.Player).WithMany(p => p.PlayerUnits)
                .HasForeignKey(d => d.PlayerId)
                .HasConstraintName("FK__PlayerUni__playe__25518C17");

            entity.HasOne(d => d.Units).WithMany(p => p.PlayerUnits)
                .HasForeignKey(d => d.UnitsId)
                .HasConstraintName("FK__PlayerUni__units__2645B050");
        });

        modelBuilder.Entity<Resource>(entity =>
        {
            entity.HasKey(e => e.ResourcesId).HasName("PK__Resource__F6DB0162F980C05F");

            entity.Property(e => e.ResourcesId)
                .ValueGeneratedNever()
                .HasColumnName("resources_id");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Technology>(entity =>
        {
            entity.HasKey(e => e.TechnologiesId).HasName("PK__Technolo__181FA18129E5FFEA");

            entity.Property(e => e.TechnologiesId)
                .ValueGeneratedNever()
                .HasColumnName("technologies_id");
            entity.Property(e => e.Description)
                .HasMaxLength(100)
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Unit>(entity =>
        {
            entity.HasKey(e => e.UnitsId).HasName("PK__Units__E2E4534555941260");

            entity.Property(e => e.UnitsId)
                .ValueGeneratedNever()
                .HasColumnName("units_id");
            entity.Property(e => e.AttackPower).HasColumnName("attack_power");
            entity.Property(e => e.DefensePower).HasColumnName("defense_power");
            entity.Property(e => e.FactionId).HasColumnName("faction_id");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .HasColumnName("name");
            entity.Property(e => e.TrainingTime).HasColumnName("training_time");

            entity.HasOne(d => d.Faction).WithMany(p => p.Units)
                .HasForeignKey(d => d.FactionId)
                .HasConstraintName("FK__Units__faction_i__22751F6C");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
