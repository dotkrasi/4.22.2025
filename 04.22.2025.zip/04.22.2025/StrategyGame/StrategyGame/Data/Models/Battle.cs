﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class Battle
{
    public int BattlesId { get; set; }

    public int? AttackerId { get; set; }

    public int? DefenderId { get; set; }

    public DateOnly? StartedAt { get; set; }

    public DateOnly? EndedAt { get; set; }

    public virtual Player? Attacker { get; set; }

    public virtual Player? Defender { get; set; }
}
