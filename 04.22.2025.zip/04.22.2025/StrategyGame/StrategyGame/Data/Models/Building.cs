﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class Building
{
    public int BuildingsId { get; set; }

    public string? Name { get; set; }

    public string? Description { get; set; }

    public int? BuildTime { get; set; }

    public int? FactionId { get; set; }

    public virtual ICollection<BattleUnit> BattleUnits { get; set; } = new List<BattleUnit>();

    public virtual Faction? Faction { get; set; }

    public virtual ICollection<PlayerBuilding> PlayerBuildings { get; set; } = new List<PlayerBuilding>();
}
