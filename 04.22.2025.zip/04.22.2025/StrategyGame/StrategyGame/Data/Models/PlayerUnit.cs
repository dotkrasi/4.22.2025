﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerUnit
{
    public int PlayerUnitsId { get; set; }

    public int? PlayerId { get; set; }

    public int? UnitsId { get; set; }

    public int? Quantity { get; set; }

    public virtual Player? Player { get; set; }

    public virtual Unit? Units { get; set; }
}
