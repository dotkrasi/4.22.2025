﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerLocation
{
    public int PlayerlocationsId { get; set; }

    public int? PlayerId { get; set; }

    public int? MapsId { get; set; }

    public int? X { get; set; }

    public int? Y { get; set; }

    public virtual Map? Maps { get; set; }

    public virtual Player? Player { get; set; }
}
