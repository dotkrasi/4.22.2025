﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class PlayerFaction
{
    public int PlayerFactionsId { get; set; }

    public int? PlayerId { get; set; }

    public int? FactionId { get; set; }

    public DateOnly? StartDate { get; set; }

    public virtual Faction? Faction { get; set; }

    public virtual Player? Player { get; set; }
}
