﻿using System;
using System.Collections.Generic;

namespace StrategyGame.Data.Models;

public partial class Technology
{
    public int TechnologiesId { get; set; }

    public string? Name { get; set; }

    public string? Description { get; set; }

    public int? ResearchTime { get; set; }

    public virtual ICollection<PlayerTechnology> PlayerTechnologies { get; set; } = new List<PlayerTechnology>();
}
