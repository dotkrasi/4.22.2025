﻿using Microsoft.EntityFrameworkCore;
using StrategyGame.Data;

public class Program
{

    static void Main(string[] args)
    {
        using var context = new StrategyGameContext();

        Console.WriteLine("1. Players with resources");
        method1();

        Console.WriteLine("\n2. Last 5 battles");
        method2();

        Console.WriteLine("\n3. Buildings and units for Humans");
        method3();
    }

    public static void method1()
    {
        StrategyGameContext context = new StrategyGameContext();

        var playersWithResources = context.Players
            .Include(p => p.PlayerResources)
                .ThenInclude(pr => pr.Resources)
            .ToList();

        foreach (var player in playersWithResources)
        {
            Console.WriteLine($"Player: {player.Username}");
            foreach (var res in player.PlayerResources)
            {
                Console.WriteLine($"  {res.Resources.Name}: {res.Amount}");
            }
        }
    }
    public static void method2()
    {
        StrategyGameContext context = new StrategyGameContext();

        var last5Battles = context.Battles
        .Include(b => b.Attacker)
        .Include(b => b.Defender)
        .OrderByDescending(b => b.EndedAt)
        .Take(5)
        .ToList();

        foreach (var b in last5Battles)
        {
            Console.WriteLine($"{b.StartedAt} - {b.Attacker.Username} vs {b.Defender.Username}");
        }

    }
    public static void method3()
    {

        StrategyGameContext context = new StrategyGameContext();
        var humans = context.Factions
        .Include(f => f.Buildings)
        .Include(f => f.Units)
        .FirstOrDefault(f => f.Name == "Humans");

        if (humans != null)
        {
            Console.WriteLine("Buildings:");
            foreach (var b in humans.Buildings)
                Console.WriteLine($"- {b.Name}");

            Console.WriteLine("Units:");
            foreach (var u in humans.Units)
                Console.WriteLine($"- {u.Name}");
        }

    }
}