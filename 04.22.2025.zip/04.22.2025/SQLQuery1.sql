CREATE DATABASE StrategyGame

CREATE TABLE Players
(
player_id INT PRIMARY KEY,
username NVARCHAR(100),
email NVARCHAR(100),
CreatedAt date
)

CREATE TABLE Factions
(
factions_id INT PRIMARY KEY,
name NVARCHAR(100),
description NVARCHAR(100)
)

CREATE TABLE PlayerFactions
(
player_factions_id INT PRIMARY KEY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
faction_id INT FOREIGN KEY REFERENCES Factions(factions_id),
StartDate date
)

CREATE TABLE Buildings
(
buildings_id INT PRIMARY KEY,
name NVARCHAR(100),
description NVARCHAR(100),
BuildTime INT,
faction_id INT FOREIGN KEY REFERENCES Factions(factions_id)
)

CREATE TABLE PlayerBuildings
(
Id INT PRIMARY KEY IDENTITY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
buildings_id INT FOREIGN KEY REFERENCES Buildings(buildings_id),
level INT,
BuiltAt DATE
)

CREATE TABLE Units
(
units_id INT PRIMARY KEY,
name NVARCHAR(100),
attack_power INT,
defense_power INT,
training_time INT,
faction_id INT FOREIGN KEY REFERENCES FactionS(factions_id)
)

CREATE TABLE PlayerUnits
(
player_units_id INT PRIMARY KEY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
units_id INT FOREIGN KEY REFERENCES Units(units_id),
Quantity INT
)

CREATE TABLE Resources
(
resources_id INT PRIMARY KEY,
name NVARCHAR(100),
description NVARCHAR(100)
)

CREATE TABLE PlayerResources
(
player_resources_id INT PRIMARY KEY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
resources_id INT FOREIGN KEY REFERENCES Resources(resources_id),
Amount INT
)

CREATE TABLE Battles
(
battles_id INT PRIMARY KEY,
attacker_id INT FOREIGN KEY REFERENCES Players(player_id),
defender_id INT FOREIGN KEY REFERENCES Players(player_id),
StartedAt date,
EndedAt date,
-- Result (enum: AttackerWin, DefenderWin, Draw)
)

CREATE TABLE BattleUnits
(
battle_units_id INT PRIMARY KEY,
BattleId INT FOREIGN KEY REFERENCES Buildings(buildings_id),
UnitId INT FOREIGN KEY REFERENCES Units(units_id),
PlayerId INT FOREIGN KEY REFERENCES Players(player_id),
Quantity INT
)

CREATE TABLE Maps
(
maps_id INT PRIMARY KEY,
name NVARCHAR(100),
SizeX INT,
SizeY INT,
description NVARCHAR(100)
)

CREATE TABLE PlayerLocations
(
playerlocations_id INT PRIMARY KEY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
maps_id INT FOREIGN KEY REFERENCES Maps(maps_id),
X INT,
Y INT
)

CREATE TABLE Technologies
(
technologies_id INT PRIMARY KEY,
name NVARCHAR(100),
description NVARCHAR(100),
ResearchTime INT
)

CREATE TABLE PlayerTechnologies
(
player_technologies_id INT PRIMARY KEY,
player_id INT FOREIGN KEY REFERENCES Players(player_id),
technologies_id INT FOREIGN KEY REFERENCES Technologies(technologies_id),
IsResearched NVARCHAR,
ResearchedAt DATE
)


INSERT INTO Factions(factions_id,name,description)
VALUES
(1, 'Humans', 'Balanced race with strong economy.'),
(2, 'Orcs', 'Strong melee units, weak defenses.')

INSERT INTO Buildings(buildings_id,name,description,BuildTime,faction_id)
VALUES
(1, 'Barracks', 'Trains infantry.', 60, 1), 
(2, 'Farm', 'Produces food.', 30, 1)


INSERT INTO Units(units_id,name,attack_power, defense_power, training_time, faction_id)
VALUES
(1, 'Swordsman', 10, 5, 45, 1),
(2, 'Archer', 7, 3, 30, 1)

INSERT INTO Resources(resources_id,name,description)
VALUES
( 1, 'Gold', 'Used for building and training.'), 
( 2, 'Food', 'Required for units to survive.')

INSERT INTO Technologies(technologies_id,name,description,ResearchTime)
VALUES
( 1, 'Advanced Metallurgy', 'Increases attack by 10%', 120),
( 2, 'Efficient Farming', 'Increases food production by 20%', 90)

INSERT INTO Maps(maps_id,name,SizeX,SizeY,description)
VALUES
(1, 'Valley of Kings', 100, 100, 'A balanced map with hills and forests.')